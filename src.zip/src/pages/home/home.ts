import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';
import {SendRequestService} from "../../app/services/send-request";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  public phoneNumberMask = ['(', /[0-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/];

  public name: string = '';

  public phoneNumber: string = '';

  public askUser: boolean = true;
  public formUser: boolean = false;
  public waitingUser: boolean = false;


  constructor(public navCtrl: NavController, private sendData: SendRequestService) {
  }

  public inQueue() {
    this.askUser = false;
    this.waitingUser = true;
    this.sendData.request().subscribe();

    setTimeout(() => {
      this.askUser = true;
      this.waitingUser = false;
    }, 4000);
  }

  public inQueueWithSMS($event) {
    //console.log(123);
    this.askUser = false;
    this.formUser = true;
    this.waitingUser = false;
    //this.nameInput.nativeElement.focus();
  }

  public getPlaceInQueue(value) {
    // Запрос
    this.sendData.request(value.name, value.phoneNumber).subscribe();

    this.askUser = false;
    this.formUser = false;
    this.waitingUser = true;

    // Начало промиса
    setTimeout(() => {
      this.askUser = true;
      this.formUser = false;
      this.waitingUser = false;
    }, 4000);

  }

}
