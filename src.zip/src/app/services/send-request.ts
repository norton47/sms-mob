import {Injectable}  from '@angular/core';
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import 'rxjs/add/operator/map';
import {Observable} from "rxjs";

@Injectable()
export class SendRequestService {

    url = `https://my.citrus.ua/papi/service_center/zayavka`;

    constructor( private http: Http) {}

    public request(name: string = '', phone: string = ''){

        let requestOptions = new RequestOptions();
        let params: URLSearchParams = new URLSearchParams();
        params.set('name', name);
        params.set('phone', phone);

        requestOptions.search = params;

        return this.http.get(this.url, requestOptions)
            .map(this.extractData)
            .catch(this.handleError);
    }

    private extractData(res: Response) {
        let body = res.json();
        return body || { };
    }
    private handleError (error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}